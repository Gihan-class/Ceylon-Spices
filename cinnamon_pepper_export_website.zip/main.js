const btn = document.getElementById('menuBtn');
const nav = document.getElementById('nav');

if (btn && nav) {
  btn.addEventListener('click', () => nav.classList.toggle('open'));
}

document.addEventListener('click', (e) => {
  if (!nav || !btn) return;
  if (!nav.contains(e.target) && !btn.contains(e.target)) nav.classList.remove('open');
});
